#include "stdio.h"
#include "stdint.h"

// 字节求址宏定义
#define BYTE0(dwTemp)       (*(char *)(&dwTemp))

// 定义一个发送函数(含2个数据)
void SendCurve(int8_t data1, int8_t data2);

int main()
{
    int8_t data1 = 100;
    int8_t data2 = -50;

	// 发送10次数据
    for (int32_t i = 0; i < 10; i++)
    {
        SendCurve(data1, data2);
        data1++;
        data2++;
    }

    return 0;
}

void SendCurve(int8_t data1, int8_t data2)
{
    uint8_t dataBuff[(2 + 1) * sizeof(int8_t)];  //缓存大小：(数据数量 + 1) * sizeof(int8_t)
    int32_t cnt = 0;
    
    dataBuff[cnt++]=BYTE0(data1); //第一个数据，如电压

    dataBuff[cnt++]=BYTE0(data2); //第二个数据，如电流

    dataBuff[cnt++]=0x80;         //结束标志

    // 该函数将dataBuff发送出去，可根据实际替换成你的发送函数
    for(int32_t i = 0; i < cnt; i++)
    {
        printf("%c",dataBuff[i]);
    }
}
