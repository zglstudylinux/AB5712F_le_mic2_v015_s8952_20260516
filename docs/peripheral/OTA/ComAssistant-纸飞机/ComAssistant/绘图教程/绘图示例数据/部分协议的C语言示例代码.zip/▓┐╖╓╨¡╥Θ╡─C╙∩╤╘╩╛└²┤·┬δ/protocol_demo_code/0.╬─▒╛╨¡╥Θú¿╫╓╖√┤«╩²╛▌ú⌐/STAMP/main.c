#include "stdio.h"
#include "stdint.h"

// 模拟获取系统的运行时间，应该替换成自己的实现
static uint32_t timestamp = 0;
uint32_t get_boot_time_ms(void)
{
    return timestamp;
}

// 定义打印宏函数
#define PRINT(title, fmt, args...) printf("<%d>{"#title"}"fmt"\n", get_boot_time_ms(), ##args)

int main()
{
    uint8_t data1 = 100;
    int16_t data2 = 200;
    float   data3 = 300.5432f;
    
    for (int32_t i = 0; i < 10; i++)
    {
        // 绘图
        PRINT(plotter, "%d, %d, %.2f", data1, data2, data3);
        data1++; data2++; data3++;
        
        // 分窗
        PRINT(count, "hello, print count:%d", i);
        PRINT(friend, "hello, my friend", i);
        
        // 模拟时间增加
        timestamp++;
    }
    
    return 0;
}